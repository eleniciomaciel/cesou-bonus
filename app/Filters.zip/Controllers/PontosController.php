<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PontosController extends BaseController
{
    public function index()
    {
        //
    }
}
