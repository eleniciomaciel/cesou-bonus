<div class="row">
    <div class="col-sm-4">
        <div class="card">
            <div class="card-body p-3 position-relative">
                <div class="row">
                    <div class="col-7 text-start">
                        <p class="text-sm mb-1 text-capitalize font-weight-bold">Vendas</p>
                        <h5 class="cls_results_total_vendas_loja font-weight-bolder mb-0" id="results_total_vendas_loja">
                            ...
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-4 mt-sm-0 mt-4">
        <div class="card">
            <div class="card-body p-3 position-relative">
                <div class="row">
                    <div class="col-7 text-start">
                        <p class="text-sm mb-1 text-capitalize font-weight-bold">Clientes</p>
                        <h5 class="cls_results_total_loja font-weight-bolder mb-0" id="results_total_clientes_loja">
                            ...
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-4 mt-sm-0 mt-4">
        <div class="card">
            <div class="card-body p-3 position-relative">
                <div class="row">
                    <div class="col-7 text-start">
                        <p class="text-sm mb-1 text-capitalize font-weight-bold">Trocas</p>
                        <h5 class="cls_results_trocas_loja font-weight-bolder mb-0" id="results_trocas">
                            ...
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>