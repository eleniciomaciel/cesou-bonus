<section class="py-3">
    <div class="row">
        <div class="col-md-8 me-auto text-left">
            <h5 style="color: white;">Promoções agora!!!</h5>
            <p style="color: white;">Escolha qual loja você quer trocar seus pontos.</p>
        </div>
    </div>
    <div class="row mt-lg-4 mt-2">
        
        <div id="results_card_promocional"></div>

    </div>
</section>